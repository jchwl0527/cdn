import json
import time
import requests

while True:
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())#获取当前主机时间 (根据时区不同 获取到的时间不同)
    url = 'https://ti.qq.com/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0x587_52?sdkappid=20344'
    headers = {
        'Host': 'ti.qq.com',
        'Content-Length': '18',
        'Accept': 'application/json',
        'Cookie': 'p_uin=o3074193836; p_skey=0H8K5RkDzGmL2XLBuHr9YcJdg210OSO3Ou7PZsy1dSw_',
    }#获取你的QQcookies uin以及skey uin格式为(o你的QQ号)
    data = f'{{"str_nick":"{now}"}}'
    response = requests.post(url=url, headers=headers, data=data)
    res = json.loads(response.text)
    text=res['ActionStatus']
    if text.strip()=='OK':
       print("替换QQ昵称成功")
       print("当前修改昵称时间",now)
    else : 
       print("替换QQ昵称失败") 
       print("当前修改昵称时间",now)
    time.sleep(60)#修改QQ昵称时间间隔 按照秒计算 60秒修改一次 最少30 少于30请求过快将被API拉黑