<?php
$url='https://ti.qq.com/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0x587_52?sdkappid=20344';
$qq='';//填写你的QQ号
$skey=''; //填写你的QQskey值
$time=date('Y-m-d G:i:s', time());
$data='{"str_nick":"'.$time.'"}';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_COOKIE,'p_uin=o'.$qq.'; p_skey='.$skey.'');
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($data)));
$data = curl_exec($ch);
$json = json_decode($data, true);
if($json['ActionStatus']=="OK"){
  echo "修改QQ昵称成功！";
  echo "当前修改昵称时间：".$time;
}else{
  echo "修改QQ昵称失败！";
  echo "当前修改昵称时间：".$time;
}
?>